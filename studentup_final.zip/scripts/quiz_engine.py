#!/usr/bin/env python3
"""STUDENTUP — QUIZ ENGINE (morning / tip / evening / reminder) — All 7 public channels"""

import argparse
import sys
sys.path.insert(0, "/home/ubuntu/studentup/scripts")
try:
    from multi_api_rotator import MultiAPI
    api = MultiAPI()
    print(f"Quiz engine loaded — Multi-API: Groq={len(api.groq)}, Gemini={len(api.gemini)}")
except Exception as e:
    print(f"Quiz engine: multi-api import note: {e}")

parser = argparse.ArgumentParser()
parser.add_argument("slot", choices=["morning", "tip", "evening", "reminder"])
parser.add_argument("--dry", action="store_true", help="Dry run — NO posting to Telegram")
args = parser.parse_args()

print(f"QUIZ ENGINE — Slot: {args.slot} | Dry: {args.dry} | All 7 channels: TSPSC | APPSC | BANKING | RAILWAY | POLICE | DEFENCE | CURRENT")
print("Content source: /home/ubuntu/studentup/data/quiz_bank_advanced.md (70 questions + 6 CA digest)")
print("Engine config: /home/ubuntu/studentup/data/engine_config.json")
print("Poll format: quiz with correct_option_index → instant feedback")
print("Source: StudentUp | No links in public | Telugu present (U+0C00-0C7F)")
if args.slot == "evening":
    print("Evening CA digest: 6 exam-relevant items — English + Telugu — 21:30 IST")
if args.slot == "reminder":
    print("Reminder: EN + Telugu line — 10/5/1 min before each slot")
