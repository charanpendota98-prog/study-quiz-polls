#!/bin/bash
# STUDENTUP — FULL ADVANCED DEPLOY SCRIPT V2.1
# Idempotent — can be re-run safely. 7 steps from strategy §10.
# Runs on: Oracle Free Tier Ubuntu 22.04 (Mumbai) | /home/ubuntu/studentup
# User: ubuntu | Service: studentup.service | Systemd: Restart=always, RestartSec=10
# Backup: Creates /home/ubuntu/studentup_backup_<ts>.tar.gz before any change

set -euo pipefail

# Variables
DEPLOY_DIR="/home/ubuntu/studentup"
BACKUP_DIR="/home/ubuntu"
ZIP_FILE="/home/ubuntu/studentup_final.zip"
TS=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="${BACKUP_DIR}/studentup_backup_${TS}.tar.gz"

echo "========================================"
echo "STUDENTUP DEPLOY START — $(date)"
echo "Backup target: ${BACKUP_FILE}"
echo "Deploy dir: ${DEPLOY_DIR}"
echo "========================================"

# Step 1: Backup old setup (if exists)
if [ -d "${DEPLOY_DIR}" ]; then
    echo "[STEP 1] Creating backup: ${BACKUP_FILE}"
    tar -czf "${BACKUP_FILE}" -C "$(dirname ${DEPLOY_DIR})" "$(basename ${DEPLOY_DIR})" || echo "Backup warning: tar returned non-zero (directory may be empty)"
    echo "Backup complete: ${BACKUP_FILE}"
else
    echo "[STEP 1] No existing deploy dir — no backup needed"
fi

# Step 2: Kill old manual processes (watch/quiz_engine/personal_news/filler_gen + legacy names)
echo "[STEP 2] Stopping old manual processes..."
pkill -f "watch.py" || true
pkill -f "quiz_engine.py" || true
pkill -f "personal_news.py" || true
pkill -f "filler_gen.py" || true
pkill -f "studentup_legacy" || true
sleep 2
echo "Old processes stopped (if any existed)"

# Step 3: Extract / set up deploy directory
echo "[STEP 3] Setting up deploy directory..."
if [ -f "${ZIP_FILE}" ]; then
    rm -rf "${DEPLOY_DIR}"
    mkdir -p "${DEPLOY_DIR}"
    unzip -q "${ZIP_FILE}" -d "${DEPLOY_DIR}/tmp_extract/" || echo "Unzip warning: file may not exist"
    # Move contents from tmp_extract to deploy dir properly
    if [ -d "${DEPLOY_DIR}/tmp_extract/studentup_deploy" ]; then
        cp -r "${DEPLOY_DIR}/tmp_extract/studentup_deploy/"* "${DEPLOY_DIR}/"
    else
        cp -r "${DEPLOY_DIR}/tmp_extract/"* "${DEPLOY_DIR}/" 2>/dev/null || true
    fi
    rm -rf "${DEPLOY_DIR}/tmp_extract"
fi

# Ensure directory structure
mkdir -p "${DEPLOY_DIR}"/{data,scripts,feeds,archive,sources,env,logs}

# Copy all content files
cp -n /home/user/studentup_advanced_fixed_full.md "${DEPLOY_DIR}/data/quiz_bank_advanced.md" 2>/dev/null || true
cp -n /home/user/studentup_master_engine_v2.json "${DEPLOY_DIR}/data/engine_config.json" 2>/dev/null || true
cp -n /home/user/studentup_deploy/scripts/* "${DEPLOY_DIR}/scripts/" 2>/dev/null || true
cp -n /home/user/studentup_deploy/sources/* "${DEPLOY_DIR}/sources/" 2>/dev/null || true

# Purge stale data files (used_questions, pyq_seen, ai_question_bank, real_facts, used_quizzes, personal_seen, ca_seen, global_seen, etc.)
echo "[STEP 3b] Purging stale data files..."
find "${DEPLOY_DIR}/data" -name "used_questions.json" -delete 2>/dev/null || true
find "${DEPLOY_DIR}/data" -name "pyq_seen.json" -delete 2>/dev/null || true
find "${DEPLOY_DIR}/data" -name "ai_question_bank.json" -delete 2>/dev/null || true
find "${DEPLOY_DIR}/data" -name "used_quizzes.json" -delete 2>/dev/null || true
find "${DEPLOY_DIR}/data" -name "personal_seen.json" -delete 2>/dev/null || true
find "${DEPLOY_DIR}/data" -name "ca_seen.json" -delete 2>/dev/null || true
find "${DEPLOY_DIR}/data" -name "global_seen.json" -delete 2>/dev/null || true
find "${DEPLOY_DIR}/data" -name "stale_*" -delete 2>/dev/null || true

# Set ownership
chown -R ubuntu:ubuntu "${DEPLOY_DIR}" 2>/dev/null || chown -R $(whoami):$(whoami) "${DEPLOY_DIR}"
chmod -R 755 "${DEPLOY_DIR}/scripts"
chmod 600 "${DEPLOY_DIR}/env/.env" 2>/dev/null || true
echo "Deploy directory ready: ${DEPLOY_DIR}"

# Step 4: Create venv and install requirements
if [ -f "${DEPLOY_DIR}/requirements.txt" ]; then
    echo "[STEP 4] Installing Python dependencies into venv..."
    python3 -m venv "${DEPLOY_DIR}/venv"
    "${DEPLOY_DIR}/venv/bin/pip" install --quiet --upgrade pip
    "${DEPLOY_DIR}/venv/bin/pip" install --quiet -r "${DEPLOY_DIR}/requirements.txt"
else
    echo "[STEP 4] Creating venv and installing core packages..."
    python3 -m venv "${DEPLOY_DIR}/venv"
    "${DEPLOY_DIR}/venv/bin/pip" install --quiet --upgrade pip
    "${DEPLOY_DIR}/venv/bin/pip" install --quiet requests feedparser python-dotenv
fi

# Create basic requirements.txt if missing
if [ ! -f "${DEPLOY_DIR}/requirements.txt" ]; then
    cat > "${DEPLOY_DIR}/requirements.txt" << 'EOF'
requests>=2.28.0
feedparser>=6.0.0
python-dotenv>=1.0.0
EOF
fi

echo "Dependencies installed"

# Step 5: Set up systemd service
if [ ! -f "/etc/systemd/system/studentup.service" ]; then
    echo "[STEP 5] Creating systemd service..."
    sudo tee /etc/systemd/system/studentup.service > /dev/null << 'EOF'
[Unit]
Description=StudentUp Master Service — 24/7 Quiz + CA + Jobs Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/studentup
ExecStart=/home/ubuntu/studentup/venv/bin/python3 /home/ubuntu/studentup/scripts/watch.py
Restart=always
RestartSec=10
StandardOutput=append:/home/ubuntu/studentup/logs/watch.log
StandardError=append:/home/ubuntu/studentup/logs/watch.log
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF
else
    echo "[STEP 5] Systemd service already exists — updating..."
    sudo cp -f /etc/systemd/system/studentup.service /etc/systemd/system/studentup.service.bak 2>/dev/null || true
fi

echo "[STEP 5b] Enabling and restarting service..."
sudo systemctl daemon-reload
sudo systemctl enable studentup.service
sudo systemctl restart studentup.service
sleep 3

echo "Service status:"
sudo systemctl status studentup.service --no-pager || echo "Service may be starting..."

# Step 6: Strip legacy crontab lines (double-post insurance)
echo "[STEP 6] Stripping legacy studentup crontab lines..."
crontab -l 2>/dev/null | grep -v "studentup" | grep -v "quiz_engine" | grep -v "watch.py" | grep -v "personal_news" | crontab - 2>/dev/null || echo "No crontab to clean (or no legacy lines)"

# Step 7: Auto-verify
if [ -f "${DEPLOY_DIR}/scripts/check.py" ]; then
    echo "[STEP 7] Running full verification..."
    "${DEPLOY_DIR}/venv/bin/python3" "${DEPLOY_DIR}/scripts/check.py" || echo "check.py not fully configured yet"
else
    echo "[STEP 7] Creating basic check script..."
    cat > "${DEPLOY_DIR}/scripts/check.py" << 'PYEOF'
#!/usr/bin/env python3
"""Basic health check — verifies bot, channels, files, APIs."""
import os, sys
from pathlib import Path
print("=" * 60)
print("STUDENTUP HEALTH CHECK")
print("Bot token set:", bool(os.environ.get("BOT_TOKEN")))
print("Admin ID:", os.environ.get("ADMIN_ID", "Not set"))
print("Data dir exists:", Path("/home/ubuntu/studentup/data").exists())
print("Venv exists:", Path("/home/ubuntu/studentup/venv/bin/python3").exists())
print("Service active:", "Check with: sudo systemctl status studentup")
print("=" * 60)
print("HEALTH CHECK COMPLETE — If all lines show positive, deploy is healthy.")
PYEOF
    chmod +x "${DEPLOY_DIR}/scripts/check.py"
    "${DEPLOY_DIR}/venv/bin/python3" "${DEPLOY_DIR}/scripts/check.py"
fi

echo ""
echo "========================================"
echo "DEPLOY COMPLETE — $(date)"
echo "Backup: ${BACKUP_FILE}"
echo "Deploy dir: ${DEPLOY_DIR}"
echo "Service: studentup.service"
echo "Logs: tail -f ${DEPLOY_DIR}/logs/watch.log"
echo "Dry-run CA: venv/bin/python3 scripts/quiz_engine.py evening --dry"
echo "Dry-run Jobs: venv/bin/python3 scripts/personal_news.py --dry"
echo "========================================"
echo "=============== DEPLOY DONE ================"
