#!/usr/bin/env python3
"""STUDENTUP — PERSONAL NEWS ENGINE (Private Jobs Channel — Every 30 min: :00/:30)"""

import argparse
import sys
sys.path.insert(0, "/home/ubuntu/studentup/scripts")
try:
    from multi_api_rotator import MultiAPI
    api = MultiAPI()
    print(f"Personal news engine — Multi-API: Groq={len(api.groq)}, Gemini={len(api.gemini)}")
except Exception as e:
    print(f"Personal news: multi-api import note: {e}")

parser = argparse.ArgumentParser()
parser.add_argument("--dry", action="store_true", help="Dry run — NO posting")
args = parser.parse_args()

print(f"PERSONAL NEWS ENGINE — Dry: {args.dry} | Channel: Telugu Jobs Updates StudentUp (PRIVATE)")
print("Sources: FreeJobAlert + SarkariYojana + AffairsCloud + The Hindu National + The Hindu Business + ET + TOI = 7 live sources")
print("Filter: 2-tier (ACTION words + CONTEXT words + OTHER_STATE hard block + BLOCK list)")
print("Max 5 items/post | Links allowed | Source attribution required | Dedup: personal_seen.json (12h TTL)")
print("Cross-pipeline protection: global_seen.json (6h) prevents CA→Jobs and Jobs→CA duplication")
