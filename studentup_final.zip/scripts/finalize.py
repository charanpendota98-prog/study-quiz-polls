#!/usr/bin/env python3
"""STUDENTUP — FINALIZE / VALIDATION GATE — Runs before every build/deploy."""

import re
from pathlib import Path

def validate_bank(file_path):
    with open(file_path) as f:
        content = f.read()
    errors = []
    # Check Telugu script presence
    if "⤷" not in content:
        errors.append("Missing Telugu translation marker (⤷)")
    # Check blocked words
    blocked = ["cricket", "ipl", "bollywood", "movie", "actor", "weather", "drama", "viral"]
    for w in blocked:
        if w.lower() in content.lower():
            # Only flag if actually present (not in explanation notes)
            errors.append(f"Possible blocked word detected: {w}")
    # Check option count per question (rough count)
    if content.count("Options EN:") < 10:
        errors.append("Less than 10 EN option blocks expected for full bank")
    return errors

if __name__ == "__main__":
    bank_path = Path("/home/ubuntu/studentup/data/quiz_bank_advanced.md")
    if bank_path.exists():
        errors = validate_bank(bank_path)
        if errors:
            print("VALIDATION GATE — ERRORS FOUND:")
            for e in errors:
                print(f"  ❌ {e}")
        else:
            print("VALIDATION GATE PASSED — Zero errors. Bank ready for deploy.")
        print(f"File: {bank_path} | Size: {bank_path.stat().st_size} bytes")
    else:
        print("VALIDATION GATE — Bank file not found at expected path.")
