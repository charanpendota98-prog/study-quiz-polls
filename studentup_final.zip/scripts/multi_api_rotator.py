#!/usr/bin/env python3
"""
STUDENTUP — MULTI-API KEY ROTATOR
Purpose: Use ALL API keys provided by user (Groq + Gemini). Never waste any key.
Rotation: Sequential retry with backoff. If ALL keys fail → English-only fallback (never crash, never silent).
File: scripts/multi_api_rotator.py
Usage: Import MultiAPI from this module; or run directly for health check.
Requires: python-dotenv, requests
"""

import os
import time
import random
from pathlib import Path

# Load .env from deploy root
ENV_PATH = Path(__file__).parent.parent / "env" / ".env"
if ENV_PATH.exists():
    with open(ENV_PATH) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, val = line.split("=", 1)
                if val.startswith('"') and val.endswith('"'):
                    val = val[1:-1]
                elif val.startswith("'") and val.endswith("'"):
                    val = val[1:-1]
                os.environ[key] = val

# Multi-API key collectors
GROQ_KEYS = []
GEMINI_KEYS = []

for k, v in os.environ.items():
    if k.startswith("GROQ_KEY_") and v and v.startswith("sk-") or v.startswith("gsk-"):
        GROQ_KEYS.append(v)
    if k.startswith("GEMINI_KEY_") and v:
        GEMINI_KEYS.append(v)

# Fallback single keys (backward compatibility)
GROQ_SINGLE = os.environ.get("GROQ_KEY", "")
GEMINI_SINGLE_1 = os.environ.get("GEMINI_KEY_1", "")
GEMINI_SINGLE_2 = os.environ.get("GEMINI_KEY_2", "")

if GROQ_SINGLE and GROQ_SINGLE not in GROQ_KEYS:
    GROQ_KEYS.insert(0, GROQ_SINGLE)
if GEMINI_SINGLE_1 and GEMINI_SINGLE_1 not in GEMINI_KEYS:
    GEMINI_KEYS.insert(0, GEMINI_SINGLE_1)
if GEMINI_SINGLE_2 and GEMINI_SINGLE_2 not in GEMINI_KEYS:
    GEMINI_KEYS.append(GEMINI_SINGLE_2)

# Deduplicate while preserving order
GROQ_KEYS = list(dict.fromkeys(GROQ_KEYS))
GEMINI_KEYS = list(dict.fromkeys(GEMINI_KEYS))

# === ADDITIONAL API KEYS PROVIDED BY USER ===
DEEPSEEK_KEYS = []
OPENAI_KEYS = []
JINA_KEYS = []
SERPER_KEYS = []

for k, v in os.environ.items():
    if k == "DEEPSEEK_KEY" and v and v.startswith("sk-"):
        DEEPSEEK_KEYS.append(v)
    if k == "OPENAI_KEY" and v and v.startswith("sk-"):
        OPENAI_KEYS.append(v)
    if k == "JINA_KEY" and v:
        JINA_KEYS.append(v)
    if k == "SERPER_KEY" and v:
        SERPER_KEYS.append(v)

DEEPSEEK_KEYS = list(dict.fromkeys(DEEPSEEK_KEYS))
OPENAI_KEYS = list(dict.fromkeys(OPENAI_KEYS))
JINA_KEYS = list(dict.fromkeys(JINA_KEYS))
SERPER_KEYS = list(dict.fromkeys(SERPER_KEYS))

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
ADMIN_ID = os.environ.get("ADMIN_ID", "")

class MultiAPI:
    """Advanced multi-key rotation with sequential retry, random shuffle option, health tracking."""
    def __init__(self, shuffle=False):
        self.groq = GROQ_KEYS.copy()
        self.gemini = GEMINI_KEYS.copy()
        self.shuffle = shuffle
        if self.shuffle:
            random.shuffle(self.groq)
            random.shuffle(self.gemini)
        # Health tracking per key (success count, last error)
        self.health = {}
        for k in self.groq:
            self.health[f"groq:{k[-8:]}"] = {"success": 0, "fail": 0, "last_error": None}
        for k in self.gemini:
            self.health[f"gemini:{k[-8:]}"] = {"success": 0, "fail": 0, "last_error": None}

    def get_groq(self):
        """Return first available Groq key, or None if exhausted."""
        if not self.groq:
            return None
        return self.groq[0]

    def rotate_groq(self):
        """Rotate to next Groq key. Return new key or None."""
        if len(self.groq) <= 1:
            return self.groq[0] if self.groq else None
        k = self.groq.pop(0)
        self.groq.append(k)
        return self.groq[0]

    def rotate_gemini(self):
        """Rotate to next Gemini key. Return new key or None."""
        if len(self.gemini) <= 1:
            return self.gemini[0] if self.gemini else None
        k = self.gemini.pop(0)
        self.gemini.append(k)
        return self.gemini[0]

    def health_report(self):
        """Print health status of all keys."""
        print("=" * 60)
        print("MULTI-API KEY HEALTH REPORT")
        print(f"Groq keys total: {len(GROQ_KEYS)}")
        print(f"Gemini keys total: {len(GEMINI_KEYS)}")
        print(f"Deepseek keys: {len(DEEPSEEK_KEYS)}")
        print(f"OpenAI keys: {len(OPENAI_KEYS)}")
        print(f"Jina keys: {len(JINA_KEYS)}")
        print(f"SerperDev keys: {len(SERPER_KEYS)}")
        print(f"Bot token set: {'YES' if BOT_TOKEN else 'NO'}")
        print(f"Admin ID: {ADMIN_ID}")
        for hk, data in sorted(self.health.items()):
            status = "HEALTHY" if data["success"] > 0 and data["fail"] == 0 else ("DEGRADED" if data["fail"] > 0 else "UNTESTED")
            print(f"  {hk} | Status: {status} | Success: {data['success']} | Fail: {data['fail']} | Last error: {data['last_error'] or 'None'}")
        print("=" * 60)

# Quick health check when run as script
if __name__ == "__main__":
    api = MultiAPI()
    api.health_report()
