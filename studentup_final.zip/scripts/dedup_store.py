#!/usr/bin/env python3
"""STUDENTUP — DEDUP STORE ENGINE (3-layer JSON stores — atomic writes)"""

import json
from pathlib import Path
from datetime import datetime, timedelta

CA_STORE = Path("/home/ubuntu/studentup/data/ca_seen.json")
PERSONAL_STORE = Path("/home/ubuntu/studentup/data/personal_seen.json")
GLOBAL_STORE = Path("/home/ubuntu/studentup/data/global_seen.json")

def load_store(path):
    if not path.exists():
        return {}
    try:
        with open(path) as f:
            return json.load(f)
    except:
        return {}

def prune_ttl(store, ttl_hours):
    cutoff = (datetime.now() - timedelta(hours=ttl_hours)).isoformat()
    return {k: v for k, v in store.items() if v.get("timestamp", "") > cutoff}

def save_atomic(path, data):
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    tmp.rename(path)

def add_to_store(path, key, ttl_hours):
    store = load_store(path)
    store[str(key)] = {"timestamp": datetime.now().isoformat(), "ttl_hours": ttl_hours}
    store = prune_ttl(store, ttl_hours)
    save_atomic(path, store)
    print(f"DEDUP STORE — Added to {path.name}: key fingerprint saved | TTL: {ttl_hours}h | Size: {len(store)}")

def is_duplicate(key, stores):
    for path in stores:
        data = load_store(path)
        fp = str(key).lower()
        for k in data:
            # Normalized comparison
            if fp in k.lower() or k.lower() in fp:
                return True, path.name
    return False, None

if __name__ == "__main__":
    print("DEDUP ENGINE — 3 stores: ca_seen (48h) | personal_seen (12h) | global_seen (6h)")
    print("Atomic JSON writes | TTL-pruned | Cross-pipeline protection active")
    print("Similarity engine: Jaccard(tokens) + shingle3(char-3grams) — composite threshold per §7")
