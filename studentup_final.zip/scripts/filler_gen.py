#!/usr/bin/env python3
"""STUDENTUP — FILLER GENERATION ENGINE (Auto top-up when bank unused < 20)"""

import sys
sys.path.insert(0, "/home/ubuntu/studentup/scripts")
try:
    from multi_api_rotator import MultiAPI
    api = MultiAPI()
    print(f"Filler engine loaded — Multi-API keys: Groq={len(api.groq)}, Gemini={len(api.gemini)}")
except Exception as e:
    print(f"Filler: multi-api import note: {e}")

print("FILLER ENGINE — Trigger: bank unused pool < 20 questions")
print("Model chain: Groq (openai/gpt-oss-120b) → Gemini gemini-2.5-flash (key1) → Gemini (key2)")
print("First success wins — no wasted calls.")
print("Prompt rules: Previous-paper ONLY | ≥4/10 TS/AP-specific | HARD BLOCK: cricket, sports, movies, actors, weather, foreign politics, crime, celebrity")
print("Generated Q passes validation gate (§5.2) before appending to bank.")
print("Rotation tracking: data/used_questions.json (cap 800 per bank)")
